﻿using System.Collections.Generic;
using MyAppp.Models;

namespace MyAppp.Data
{
    public interface ITodosData
    {
        IList<Todo> GetTodos();
        void AddTodo(Todo todo);
        void RemoveTodo(int todoId);
        void Update(Todo todo);
    }
}